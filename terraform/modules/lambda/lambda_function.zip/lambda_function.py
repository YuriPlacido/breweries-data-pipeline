import json
import boto3
import os

def lambda_handler(event, context):
    glue_client = boto3.client('glue')

    # Pega o nome do crawler de uma variável de ambiente
    crawler_name = os.getenv('CRAWLER_NAME', 'breweries-crawler')

    try:
        # Iniciar o Glue Crawler
        glue_client.start_crawler(Name=crawler_name)
        print(f"Crawler {crawler_name} iniciado com sucesso.")
        
    except Exception as e:
        print(f"Erro ao iniciar o crawler: {str(e)}")
        raise e